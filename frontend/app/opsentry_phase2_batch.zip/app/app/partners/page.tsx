'use client';

import { ChangeEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  type PartnerMapRow,
  normalizeJsonRows,
  parseCsv,
  partnerRowsToCsv,
  readPartnerMap,
  splitScopes,
  subscribePartnerMap,
  writePartnerMap,
} from '@/app/lib/partner-map-store';

type DraftMap = Record<string, Pick<PartnerMapRow, 'partner' | 'scopes' | 'area' | 'status'>>;

export default function PartnersPage() {
  const [partnerRows, setPartnerRows] = useState<PartnerMapRow[]>([]);
  const [partnerSearchTerm, setPartnerSearchTerm] = useState('');
  const [filterOpen, setFilterOpen] = useState(false);
  const [filterSearchTerm, setFilterSearchTerm] = useState('');
  const [selectedScopeFilters, setSelectedScopeFilters] = useState<string[]>([]);
  const [selectedAreaFilters, setSelectedAreaFilters] = useState<string[]>([]);
  const [selectedStatusFilters, setSelectedStatusFilters] = useState<string[]>([]);
  const [jsonModalOpen, setJsonModalOpen] = useState(false);
  const [jsonInput, setJsonInput] = useState('');
  const [drafts, setDrafts] = useState<DraftMap>({});
  const [dirtyRows, setDirtyRows] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const initialRows = readPartnerMap();
    setPartnerRows(initialRows);
    setDrafts(
      Object.fromEntries(
        initialRows.map((row) => [
          row.id,
          { partner: row.partner, scopes: row.scopes, area: row.area, status: row.status },
        ])
      )
    );

    return subscribePartnerMap((rows) => {
      setPartnerRows(rows);
      setDrafts(
        Object.fromEntries(
          rows.map((row) => [
            row.id,
            { partner: row.partner, scopes: row.scopes, area: row.area, status: row.status },
          ])
        )
      );
      setDirtyRows([]);
    });
  }, []);

  const availableScopes = useMemo(
    () => [...new Set(partnerRows.flatMap((row) => splitScopes(row.scopes)))].sort((a, b) => a.localeCompare(b)),
    [partnerRows]
  );
  const availableAreas = useMemo(
    () => [...new Set(partnerRows.map((row) => row.area).filter(Boolean))].sort((a, b) => a.localeCompare(b)),
    [partnerRows]
  );
  const availableStatuses = useMemo(
    () => [...new Set(partnerRows.map((row) => row.status).filter(Boolean))].sort((a, b) => a.localeCompare(b)),
    [partnerRows]
  );

  const filteredScopeOptions = useMemo(() => {
    const term = filterSearchTerm.trim().toLowerCase();
    return !term ? availableScopes : availableScopes.filter((scope) => scope.toLowerCase().includes(term));
  }, [availableScopes, filterSearchTerm]);

  const filteredAreaOptions = useMemo(() => {
    const term = filterSearchTerm.trim().toLowerCase();
    return !term ? availableAreas : availableAreas.filter((area) => area.toLowerCase().includes(term));
  }, [availableAreas, filterSearchTerm]);

  const filteredStatusOptions = useMemo(() => {
    const term = filterSearchTerm.trim().toLowerCase();
    return !term ? availableStatuses : availableStatuses.filter((status) => status.toLowerCase().includes(term));
  }, [availableStatuses, filterSearchTerm]);

  const filteredRows = useMemo(() => {
    const term = partnerSearchTerm.trim().toLowerCase();

    return partnerRows.filter((row) => {
      const draft = drafts[row.id] ?? row;
      const extraValues = Object.values(row.extra ?? {}).join(' ').toLowerCase();
      const matchesSearch =
        !term ||
        draft.partner.toLowerCase().includes(term) ||
        draft.scopes.toLowerCase().includes(term) ||
        draft.area.toLowerCase().includes(term) ||
        draft.status.toLowerCase().includes(term) ||
        extraValues.includes(term);

      const rowScopes = splitScopes(draft.scopes);
      const matchesScope = selectedScopeFilters.length === 0 || selectedScopeFilters.some((scope) => rowScopes.includes(scope));
      const matchesArea = selectedAreaFilters.length === 0 || selectedAreaFilters.includes(draft.area);
      const matchesStatus = selectedStatusFilters.length === 0 || selectedStatusFilters.includes(draft.status);

      return matchesSearch && matchesScope && matchesArea && matchesStatus;
    });
  }, [partnerRows, drafts, partnerSearchTerm, selectedScopeFilters, selectedAreaFilters, selectedStatusFilters]);

  function toggleListValue(value: string, list: string[], setter: (next: string[]) => void) {
    if (list.includes(value)) {
      setter(list.filter((item) => item !== value));
      return;
    }
    setter([...list, value]);
  }

  function clearFilters() {
    setSelectedScopeFilters([]);
    setSelectedAreaFilters([]);
    setSelectedStatusFilters([]);
    setFilterSearchTerm('');
  }

  function updateDraft(rowId: string, field: keyof DraftMap[string], value: string) {
    setDrafts((prev) => ({
      ...prev,
      [rowId]: {
        ...(prev[rowId] ?? { partner: '', scopes: '', area: '', status: 'Mapped' }),
        [field]: value,
      },
    }));
    setDirtyRows((prev) => (prev.includes(rowId) ? prev : [...prev, rowId]));
  }

  function saveAllChanges() {
    const nextRows = partnerRows.map((row) => ({
      ...row,
      ...(drafts[row.id] ?? {}),
      updated: dirtyRows.includes(row.id) ? 'Just now' : row.updated,
    }));
    writePartnerMap(nextRows);
    setPartnerRows(nextRows);
    setDirtyRows([]);
  }

  function exportCsv() {
    const mergedRows = partnerRows.map((row) => ({ ...row, ...(drafts[row.id] ?? {}) }));
    const csv = partnerRowsToCsv(mergedRows);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'opsentry-partner-map.csv';
    link.click();
    window.URL.revokeObjectURL(url);
  }

  function openCsvPicker() {
    fileInputRef.current?.click();
  }

  async function onCsvSelected(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    const parsed = parseCsv(text);
    writePartnerMap(parsed);
    setFilterOpen(false);
    event.target.value = '';
  }

  function submitJson() {
    try {
      const parsed = JSON.parse(jsonInput) as unknown;
      const rows = Array.isArray(parsed) ? normalizeJsonRows(parsed) : normalizeJsonRows((parsed as { partners?: unknown })?.partners ?? []);
      writePartnerMap(rows);
      setJsonModalOpen(false);
      setJsonInput('');
      setFilterOpen(false);
    } catch {
      alert('Invalid JSON format. Please check your payload and try again.');
    }
  }

  return (
    <div className="app-dashboard">
      <section className="app-section">
        <div className="app-section-header compact app-section-header-inline">
          <div>
            <p className="app-section-kicker">Partners</p>
          </div>

          <div className="app-section-actions">
            <button type="button" className="button home-v2-button-primary" onClick={openCsvPicker}>
              Upload CSV
            </button>
            <button type="button" className="app-ghost-action" onClick={() => setJsonModalOpen(true)}>
              Submit JSON
            </button>
            <button type="button" className="app-ghost-action" onClick={exportCsv}>
              Export CSV
            </button>
            <button
              type="button"
              className="button home-v2-button-primary"
              onClick={saveAllChanges}
              disabled={dirtyRows.length === 0}
            >
              Save changes
            </button>
            <input ref={fileInputRef} type="file" accept=".csv" className="app-hidden-file-input" onChange={onCsvSelected} />
          </div>
        </div>

        <div className="app-table-shell">
          <div className="app-table-toolbar">
            <input
              type="text"
              className="input app-table-search"
              placeholder="Search partner name, scope, or product area"
              value={partnerSearchTerm}
              onChange={(e) => setPartnerSearchTerm(e.target.value)}
            />

            <div className="app-table-filters app-filter-container">
              <button type="button" className="app-ghost-action app-filter-chip" onClick={() => setFilterOpen((prev) => !prev)}>
                Filter
              </button>

              {filterOpen ? (
                <div className="app-filter-dropdown">
                  <input
                    type="text"
                    className="input app-filter-search"
                    placeholder="Search filters"
                    value={filterSearchTerm}
                    onChange={(e) => setFilterSearchTerm(e.target.value)}
                  />

                  <div className="app-filter-actions">
                    <button type="button" className="app-inline-link" onClick={clearFilters}>Clear all</button>
                  </div>

                  <div className="app-filter-section">
                    <strong>Scopes</strong>
                    <div className="app-filter-options">
                      {filteredScopeOptions.map((scope) => (
                        <label key={scope} className="app-filter-option">
                          <input type="checkbox" checked={selectedScopeFilters.includes(scope)} onChange={() => toggleListValue(scope, selectedScopeFilters, setSelectedScopeFilters)} />
                          <span>{scope}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="app-filter-section">
                    <strong>Areas</strong>
                    <div className="app-filter-options">
                      {filteredAreaOptions.map((area) => (
                        <label key={area} className="app-filter-option">
                          <input type="checkbox" checked={selectedAreaFilters.includes(area)} onChange={() => toggleListValue(area, selectedAreaFilters, setSelectedAreaFilters)} />
                          <span>{area}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="app-filter-section">
                    <strong>Status</strong>
                    <div className="app-filter-options">
                      {filteredStatusOptions.map((status) => (
                        <label key={status} className="app-filter-option">
                          <input type="checkbox" checked={selectedStatusFilters.includes(status)} onChange={() => toggleListValue(status, selectedStatusFilters, setSelectedStatusFilters)} />
                          <span>{status}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          </div>

          <div className="app-table-wrap">
            <table className="app-table app-editable-table">
              <thead>
                <tr>
                  <th>Partner</th>
                  <th>Scopes</th>
                  <th>Area</th>
                  <th>Status</th>
                  <th>Updated</th>
                </tr>
              </thead>
              <tbody>
                {filteredRows.map((row) => {
                  const draft = drafts[row.id] ?? row;
                  return (
                    <tr key={row.id}>
                      <td><input className="input app-table-input" value={draft.partner} onChange={(e) => updateDraft(row.id, 'partner', e.target.value)} /></td>
                      <td><input className="input app-table-input" value={draft.scopes} onChange={(e) => updateDraft(row.id, 'scopes', e.target.value)} /></td>
                      <td><input className="input app-table-input" value={draft.area} onChange={(e) => updateDraft(row.id, 'area', e.target.value)} /></td>
                      <td>
                        <select className="input app-table-input app-select" value={draft.status} onChange={(e) => updateDraft(row.id, 'status', e.target.value)}>
                          <option value="Mapped">Mapped</option>
                          <option value="Reviewing">Reviewing</option>
                          <option value="Needs update">Needs update</option>
                        </select>
                      </td>
                      <td>{row.updated}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {jsonModalOpen ? (
        <div className="app-modal-overlay" onClick={() => setJsonModalOpen(false)}>
          <div className="app-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="app-modal-header">
              <div>
                <p className="app-section-kicker">Raw JSON input</p>
                <h3 className="app-modal-title">Submit partner mapping JSON</h3>
              </div>
              <button type="button" className="app-icon-button" onClick={() => setJsonModalOpen(false)} aria-label="Close JSON modal">✕</button>
            </div>
            <textarea className="input app-json-textarea" value={jsonInput} onChange={(e) => setJsonInput(e.target.value)} placeholder={`{\n  "partners": [\n    {\n      "partner": "Northstar Bank",\n      "scopes": ["auth:legacy"],\n      "area": "Auth",\n      "status": "Mapped"\n    }\n  ]\n}`} />
            <div className="app-card-actions app-card-actions-refined">
              <button type="button" className="app-ghost-action" onClick={() => setJsonModalOpen(false)}>Cancel</button>
              <button type="button" className="button home-v2-button-primary" onClick={submitJson}>Submit JSON</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
